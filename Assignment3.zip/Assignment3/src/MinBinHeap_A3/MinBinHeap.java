package MinBinHeap_A3;
import java.util.*;
import java.io.*;

public class MinBinHeap implements Heap_Interface {
	private EntryPair[] array; // load this array
	private int size = 0;
	private static final int arraySize = 10000; // Everything in the array will
												// initially
												// be null. This is ok! Just
												// build out
												// from array[1]

	// *** PUT PERSONAL PRIVATE INSTANCES DOWN HERE ***

	public MinBinHeap() {
		this.array = new EntryPair[arraySize];
		array[0] = new EntryPair(null, -100000); // 0th will be unused for
													// simplicity
													// of child/parent
													// computations...
													// the book/animation page
													// both do this.
	}

	// Please do not remove or modify this method! Used to test your entire
	// Heap.
	@Override
	public EntryPair[] getHeap() {
		return this.array;
	}

	@Override
	public void insert(EntryPair entry) {

		int hole = size + 1;
		while (hole / 2 > 0) {
			if (array[hole / 2].getPriority() > entry.getPriority()) {
				array[hole] = array[hole / 2];
			} else {
				break;
			}
			hole = hole / 2;
	 	}			
		array[hole] = entry;
		percolateDown();
		size += 1;

	}

	@Override
	public void delMin() {
		
		if (size == 1) {
			array[1] = null;
			size = 0;
		} else {
			array[1] = array[size];
			percolateDown();
			array[size] = null;
			size--;
		}

     

	}

	@Override
	public EntryPair getMin() {
		if (size <= 0) {
			return null;
		}
		return array[1];
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public void build(EntryPair[] entries) {
		percolateDown();
		for (int i = 0; i < entries.length; i++) {
			insert(entries[i]);
			
		}
		
	}
		

	private void percolateDown() {
		int starting = 1;
		int left = 2 * starting;

		while (left < size) {
			int location = left;
			int right = left + 1;

			if (right < size) {
				if (array[right].getPriority() > array[left].getPriority()) {
					location++;
				}
			}

			if (array[left].getPriority() < array[right].priority) {
				if (array[left].getPriority() < array[left / 2].getPriority()) {
					EntryPair temp = array[starting];
					array[1] = array[left];
					array[left] = temp;

					starting = location;
					left = 2 * starting;
				} else {
					break;
				}
			} else {
				if (array[right].getPriority() < array[right / 2].getPriority()) {
					EntryPair temp = array[starting];
					array[1] = array[right];
					array[right] = temp;

					starting = location;
					left = 2 * starting;
				} else {
					break;
				}
			}

		}
	}
	
	public boolean empty() {
		// TODO Auto-generated method stub
		if (size == 0) {
			return true;
		} else {
			return false;
		}
	}

}