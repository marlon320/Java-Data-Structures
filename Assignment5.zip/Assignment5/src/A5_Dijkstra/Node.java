package A5_Dijkstra;

import java.util.HashMap;

public class Node {

	private String name;
	private long ID;
	public HashMap<String, Edge> in;
	public HashMap<String, Edge> out;
	
	
	public Node(String name, long ID) {
		this.name = name;	
		this.ID = ID;		
		in = new HashMap<String, Edge>();
		out = new HashMap<String, Edge>();
		
	}
	
	
	public long sizeOut() {
		return out.size();
	}
	
	
	public String getName() {
		return this.name;
	}
	
	public long getID() {
		return this.ID;
	}
	
	public HashMap<String, Edge> in() {
		return in;
	}
	
	public HashMap<String, Edge> out() {
		return out;
	}
	
	public long outLength() {
		return out.size();
	}
	
	public long inLength() {
		return in.size();
	}
}