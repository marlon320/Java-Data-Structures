package A5_Dijkstra;

import java.util.HashMap;
import java.util.HashSet; 
import java.util.Hashtable;

import java.util.Map;


public class DiGraph implements DiGraph_Interface {

	private Hashtable<String, Node> nodes;
	private MinBinHeap priorityQ;
	private MinBinHeap printNode;
	private HashSet <Long> nodeIDs;			// IDs for node labels
	private HashSet <Long> edgeIDs;			// IDs for edges
	private HashMap <String, Integer> distances;
	private HashMap <String, Node> visited;

	
	public DiGraph () { 
  
	  nodes = new Hashtable<String, Node>();
	  nodeIDs = new HashSet<Long>();
	  edgeIDs = new HashSet<Long>();
	  distances = new HashMap<String, Integer>();
	  visited = new HashMap<String, Node>();
	  
  }

@Override
public boolean addNode(long idNum, String label) {

	if (label == null || nodeIDs.contains(idNum)) { 
		return false;
	} else if(idNum<0){
		return false;
	} else if(nodes.containsKey(label)){
		return false; 
	}else{
		Node toBeInserted = new Node(label,idNum);	
		nodes.put(label, toBeInserted);				
		nodeIDs.add(idNum);							
		return true;
	}
}

@Override
public boolean addEdge(long idNum, String stringLabel, String destLabel, long weight, String endLabel) {
	
	if (edgeIDs.contains(idNum) || idNum < 0) {		
		return false;
	}
	if (!edgeIDs.contains(idNum) || idNum >= 0) {		
		if (nodes.containsKey(stringLabel) && nodes.containsKey(destLabel)) {	
			if (!nodes.get(stringLabel).out().containsKey(destLabel)) {		
				edgeIDs.add(idNum);						
				Node source = nodes.get(stringLabel);		
				Node destination = nodes.get(destLabel);	
				Edge edge = new Edge(endLabel, source, destination, idNum, weight);
				source.out().put(destLabel, edge);	
				destination.in().put(stringLabel, edge);
				return true;
			}
		} 
	}
	return false;
}

@Override
public boolean delNode(String label) {
	if (label != null && nodes.containsKey(label)) {	
		for (Edge EdgesInto: nodes.get(label).in.values()) {	
			Node node = EdgesInto.getCurLoc();		
			if (node != null) {
				node.out.remove(EdgesInto.getCurLoc().getName());	
				edgeIDs.remove(EdgesInto.ID);
			}
		}
		for (Edge EdgesOut: nodes.get(label).out.values()) {	 
			Node node = EdgesOut.getDestination();					
			if (node != null) {
				node.in.remove(EdgesOut.getCurLoc().getName());
				edgeIDs.remove(EdgesOut.ID);
			}
		}
		nodeIDs.remove(nodes.get(label).getID());
		nodes.remove(label);	
		return true;
		
	}
	return false;
}

@Override
public boolean delEdge(String stringLabel, String destLabel) {
	if (nodes.containsKey(stringLabel) && nodes.containsKey(destLabel)) {	
		
		Node source = nodes.get(stringLabel);		
		Node destination = nodes.get(destLabel);	
		long temp;
		if (source.out.get(destLabel) != null) {
			temp = source.out.get(destLabel).ID;	
		} else {
			return false;
		}
		source.out.remove(destLabel);		
		destination.in.remove(stringLabel);	
		edgeIDs.remove(temp);	
		return true;
	} else {
		return false;
	}
}

@Override
public long numNodes() {

	return nodes.size();
}

@Override
public long numEdges() {
	if (nodes.size() >1) {
		return edgeIDs.size();
	} else {
	   return 0;
	}
}



public ShortestPathInfo[] shortestPath(String label) {
	
	
	ShortestPathInfo[] shortest = new ShortestPathInfo[nodes.size()];
	priorityQ = new MinBinHeap();
	printNode = new MinBinHeap();
	
	for (Node node: this.nodes.values()) {
		distances.put(node.getName(), Integer.MAX_VALUE);
	}
	
	
	distances.put(label, 0);
	priorityQ.insert(new EntryPair(label, 0));
	
	while (priorityQ.size() > 0) {
		Node node = nodes.get(priorityQ.getMin().value);
		int distance = distances.get(node.getName());
		
		
		for (Map.Entry<String, Edge> edge: node.out.entrySet()) {
			Node neighbor = edge.getValue().getDestination();
			long weight = edge.getValue().weight;
			int totalWeight = (int) (distance + weight);
			
			
			if (distances.get(neighbor.getName()) > totalWeight) {
				distances.put(neighbor.getName(), totalWeight);
			}
			
			
			
			
			
			if (!visited.containsKey(neighbor.getName())) {
				priorityQ.insert(new EntryPair(neighbor.getName(), distances.get(neighbor.getName())));
			}
		}
		
		visited.put(node.getName(), node);
		printNode.insert(new EntryPair(node.getName(), distances.get(node.getName())));
		priorityQ.delMin();
	}
	
	int i = 0;
	for (Map.Entry<String, Node> node : nodes.entrySet()) {
		if (!visited.containsKey(node.getKey())) {
			shortest[i] = new ShortestPathInfo(node.getKey(), -1);
		} else {
			shortest[i] = new ShortestPathInfo(node.getKey(), distances.get(node.getKey()));
		}
		i++;
	}
	
	return shortest;
	}
}