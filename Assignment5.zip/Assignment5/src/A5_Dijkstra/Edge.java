package A5_Dijkstra;

import A5_Dijkstra.Node;

public class Edge {

	private String label;
	private Node curLocNode;
	private Node destinationNode;
	public long weight;
	public long ID;
	
	public Edge(String label, Node from, Node to, long id, long weight) {
		this.label = label;
		this.curLocNode = from;
		this.destinationNode = to;
		this.ID = id;
		this.weight = weight;
	}
	
	public String getLabel() {
		return this.label;
	}
	
	public Node getCurLoc() {
		return curLocNode;
	}
	
	public Node getDestination() {
		return destinationNode;
	}
	
	
}
