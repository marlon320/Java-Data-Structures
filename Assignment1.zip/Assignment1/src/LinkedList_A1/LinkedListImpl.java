/**
 * COMP 410
 *See inline comment descriptions for methods not described in interface.
 *
*/
package LinkedList_A1;

public class LinkedListImpl implements LIST_Interface {
  Node sentinel; //this will be the entry point to your linked list (the head)
  private int listSize=0;
  public LinkedListImpl(){//this constructor is needed for testing purposes. Please don't modify!
    sentinel=new Node(0); //Note that the root's data is not a true part of your data set!
  }
  
  //implement all methods in interface, and include the getRoot method we made for testing purposes. Feel free to implement private helper methods!
  
  public Node getRoot(){ //leave this method as is, used by the grader to grab your linkedList easily.
    return sentinel;
  }

@Override
public boolean insert(double elt, int index) {
	Node insertednode= new Node(elt);
	if(index>listSize|| index <0)
		return false;
	
	if(this.isEmpty()) {
		sentinel.next=insertednode;
		insertednode.prev =sentinel;
		sentinel.prev =insertednode;
		insertednode.next =sentinel;
		listSize++;
		return true;
	}else {
			Node n1=this.getNode(index);
			insertednode.prev= n1.prev;
			n1.prev.next = insertednode;
			n1.prev=insertednode;
			insertednode.next=n1;
			listSize++;
			
			return true;
	}
	
}

@Override
public boolean remove(int index) {
	Node thisNode = sentinel; 
	if( index > listSize - 1 || index <0) {
		return false;
	} 
	
	
	if (index == 0) {
		Node firstN = sentinel.next.next;

		sentinel.next = null;
		sentinel.next = firstN;
		firstN.prev = sentinel;
		listSize--;
		return true;
	}else if (index != listSize - 1) {
	
		for (int ind = 0; ind <= index; ind++) {
			thisNode = thisNode.next;
			if(ind == index) {
				Node nextN = thisNode.next;
				Node prevN = thisNode.prev;

				prevN.next = nextN;
				nextN.prev = prevN;
				listSize--;
			
				return true;
				
			}}
	} else {
		
				
				Node lastN = sentinel.prev.prev;
				lastN.next = sentinel;
				sentinel.prev = lastN;
				listSize--;
				return true;
			}
		
	return false;
}

public Node getNode(int index) {
	Node thisNode = sentinel;
	Node currN = new Node(0);
	for(int i = 0; i <= index; i++) {
		thisNode = thisNode.next;
		if(i == index) {
			currN = thisNode;
		}
	}
	return currN;
}
@Override
public double get(int index) {
	if (index >= 0 && index <= listSize - 1) {
		return this.getNode(index).data;
	}else {
		return Double.NaN;
	}
}

@Override
public int size() {
	return listSize;
}

@Override
public boolean isEmpty() {
	if(listSize ==0) {
		return true;
	}else {
		return false;
	}
}

@Override
public void clear() {
	sentinel = new Node(0);
	listSize=0;
	
}
}