package BST_A2;

public class BST_Node {
  String data;
  BST_Node left;
  BST_Node right;
  static BST_Node root;
  
  BST_Node(String data){ this.data=data; }

  // --- used for testing  ----------------------------------------------
  //
  // leave these 3 methods in, as is

  public String getData(){ return data; }
  public BST_Node getLeft(){ return left; }
  public BST_Node getRight(){ return right; }



  
  public boolean containsNode(String s) { 
	  if (s.compareTo(getData()) == 0) {
		  return true;
	  }
	  
	  if (s.compareTo(getData()) < 0) {
		  if (left == null) {
			  return false;
		  } else if (left.containsNode(s)) {
			  return true;
		  }
	  }
	  
	  if (s.compareTo(getData()) > 0) {
		  if (right == null) {
			  return false;
		  } else if (right.containsNode(s)) {
			  return true;
		  }
	  }
	  return false;
  }
  
  public boolean insertNode(String s) {
	  if (s.compareTo(getData()) < 0) {
		  if (left == null) {
			  left = new BST_Node(s);
		  } else {
			  left.insertNode(s);
		  }
	  } else if (s.compareTo(getData()) > 0) {
		  if (right == null) {
			  right = new BST_Node(s);
		  } else {
			  right.insertNode(s);
		  }
	  }else if(s.compareTo(getData()) ==0) {
		  return true;
	  }
	 return false;
	  
  }
  public boolean removeNode(String s){ 
		if(data.equals(s)){
			if(left!=null){
				data=left.findMax().data;
				left.removeNode(data);
				if(left.data==null)
					left=null;
			}
			else if(right!=null){
				data=right.findMin().data;
				right.removeNode(data);
				if(right.data==null)
					right=null;
			}
			else
			data=null;
			return true;
		}else if(data.compareTo(s)>0){
			if(left==null || !left.removeNode(s))
				return false;
			if(left.data==null)
				left=null;
			return true;
		}else if(data.compareTo(s)<0){
			if(right==null || !right.removeNode(s))
				return false;
			if(right.data==null)right=null;
			return true;
		}
		return false;
	}
	
 
  public BST_Node findMin(){ 
	  if(this.left==null) {
		  return this;
	  }else {
		  return this.left.findMin();
  }  
  }
  public BST_Node findMax(){ 
	  if(this.right==null) {
		  return this;
	  }else {
		  return this.right.findMax();
  }  
 }
  
  
  public int getHeight(){ 
	  int leftside;
	  int rightside;
	  
	  if(left==null && right ==null) {
		  leftside=-1;
		  rightside=-1;
	  }
	  
	  if(left==null) {
		  leftside=-1;
	  }else {
		  	leftside= left.getHeight();
	  }
	  
	  if(right==null) {
		  rightside=-1;
	  }else {
		  	rightside= right.getHeight();
	  }
	  
	  if(leftside>rightside) {
		  return 1+ leftside;
	  }
	  return 1+ rightside;
	  
  }
  
  public void getFirst(BST_Node node) {
	  root=node;
  }
  public BST_Node getRoot() {
	  return root;
  }
  
  

  // --- end fill in these methods --------------------------------------


  // --------------------------------------------------------------------
  // you may add any other methods you want to get the job done
  // --------------------------------------------------------------------
  
  public String toString(){
    return "Data: "+this.data+", Left: "+((this.left!=null)?left.data:"null")
            +",Right: "+((this.right!=null)?right.data:"null");
  }
}