package BST_A2;

public class BST implements BST_Interface {
  public BST_Node root;
  int size;
  
  public BST(){ size=0; root=null; }
  
  @Override
  //used for testing, please leave as is
  public BST_Node getRoot(){ return root; }

  public boolean insert(String s) {
	  if (empty()) {
		  root = new BST_Node(s);
		  root.getFirst(root);
		  size += 1;
		  return true;
	  } else if(contains(s)==false) {
		  root.insertNode(s);
		  size += 1;
		  return true;
	  }else {
		  return false;
		  
	  
	  }
  }
 


  public boolean remove(String s) {
	  if (empty()|| contains(s)==false) {
		  return false;
	  }	  
	  if (s.compareTo(root.data) == 0) {
		  root.removeNode(s);
		  root= root.getRoot();
		  size -= 1;
		  return true;
	  }
	  size -= 1;
	  return root.removeNode(s);
  }


public String findMin() {
	if(empty()) {
		return null;
	}else {
		return root.findMin().data;
	}
		
}


public String findMax() {
	if(empty()) {
		return null;
	}else {
		return root.findMax().data;
	}
}


public boolean empty() {
	if(size <1) {
		return true;
	}
	return false;
}

public boolean contains(String s) {
	if(empty()) {
		return false;
	}
	return root.containsNode(s);
}

public int size() {
	return size;
}


public int height() {
	if(size==0) {
		return -1;
	}else if(size==1) {
		return 0;
	}
	return root.getHeight();
}

}